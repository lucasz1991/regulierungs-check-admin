    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta content="Administrator MiniFinds" name="description" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />


