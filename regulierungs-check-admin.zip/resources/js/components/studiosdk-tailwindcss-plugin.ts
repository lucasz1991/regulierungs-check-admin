import type { PluginWithInit } from './../../../node_modules/@grapesjs/studio-sdk-plugins/dist/utils.d.ts';

type TailwindPluginOptions = {};

