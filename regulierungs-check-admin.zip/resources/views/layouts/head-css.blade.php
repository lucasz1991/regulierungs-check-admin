@yield('css')
<link rel="stylesheet" href="{{ URL::asset('build/css/icons.min.css') }}" />
<link rel="stylesheet" href="{{ URL::asset('build/css/tailwind.min.css') }}" />
<link rel="stylesheet" href="{{ URL::asset('build/libs/apexcharts/apexcharts.css') }}" />


